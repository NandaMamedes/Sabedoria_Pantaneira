# Banco de Dados

import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

CAMINHO_BANCO = os.path.join(BASE_DIR, 'BancoJogo.db')

import sqlite3
from banco_sqlite.perguntas_jogo.perguntas_historia import perguntas_historia as perguntas_historia
from banco_sqlite.perguntas_jogo.perguntas_geografia import perguntas_geografia as perguntas_geografia
from banco_sqlite.perguntas_jogo.perguntas_cultura import perguntas_cultura as perguntas_cultura
from banco_sqlite.perguntas_jogo.perguntas_meio_ambiente import perguntas_meio_ambiente as perguntas_meio_ambiente
from banco_sqlite.perguntas_jogo.perguntas_politica import perguntas_politica as perguntas_politica
from banco_sqlite.perguntas_jogo.perguntas_variedades import perguntas_variedades as perguntas_variedades
from dataclasses import dataclass

@dataclass
class Jogador:
    id: int = None
    jogador: str = ""
    pontuacao: str = ""
    nivel: str = ""
    categoria: str = ""

def conectar():
    return sqlite3.connect(CAMINHO_BANCO)

def inicializar_db():
    with conectar() as conn:
        cur = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS Perguntas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                pergunta TEXT NOT NULL,
                A TEXT NOT NULL,
                B TEXT NOT NULL,
                C TEXT NOT NULL,
                D TEXT NOT NULL,
                resposta TEXT NOT NULL,
                categoria TEXT NOT NULL,    
                dificuldade TEXT NOT NULL 
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS ranking_local (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                jogador TEXT NOT NULL,
                pontuacao TEXT NOT NULL,
                nivel TEXT NOT NULL
            )
        """)
        conn.commit()

inicializar_db()

with conectar() as conn:
    cur = conn.cursor()

    def inserir_pergunta(p):
        cur.execute("SELECT 1 FROM Perguntas WHERE pergunta = ?", (p["pergunta"],))
        if cur.fetchone() is None:
            cur.execute("""
                INSERT INTO Perguntas (
                    pergunta, A, B, C, D,
                    resposta, categoria, dificuldade
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                p["pergunta"], p["A"], p["B"], p["C"], p["D"],
                p["resposta"], p["categoria"], p["dificuldade"]
            ))

    for p in perguntas_historia:
        inserir_pergunta(p)

    for p in perguntas_geografia:
        inserir_pergunta(p)

    for p in perguntas_cultura:
        inserir_pergunta(p)

    for p in perguntas_variedades:
        inserir_pergunta(p)

    for p in perguntas_meio_ambiente:
        inserir_pergunta(p)

    for p in perguntas_politica:
        inserir_pergunta(p)

    conn.commit()

def adicionar_apelido(apelido: str):
    with conectar() as conn:
        conn.execute("INSERT INTO ranking_local (jogador, pontuacao, nivel) VALUES (?,?,?)",
                     (apelido,"N/A", "N/A"))
        conn.commit()

def obter_ultimo_apelido():
    with conectar() as conn:
        cur = conn.cursor()
        cur.execute("SELECT jogador FROM ranking_local ORDER BY id DESC LIMIT 1")
        apelido = cur.fetchone()
        return apelido[0] if apelido else ""

def apelido_existe(apelido: str) -> bool:
    with conectar() as conn:
        cur = conn.cursor()
        cur.execute("SELECT 1 FROM ranking_local WHERE jogador = ?", (apelido,))
        return cur.fetchone() is not None
    
def obter_pergunta_aleatoria_por_dificuldade(dificuldade):
    with conectar() as conn:
        cur = conn.cursor()
        cur.execute("""
            SELECT pergunta 
            FROM Perguntas 
            WHERE dificuldade = ?
            ORDER BY RANDOM() 
            LIMIT 1
        """, (dificuldade,))
        pergunta = cur.fetchone()
        print(f"🔍 Pergunta encontrada para '{dificuldade}': {pergunta}")
        return pergunta[0] if pergunta else None

def obter_opcoes(pergunta):
    with conectar() as conn:
        cur = conn.cursor()
        cur.execute('SELECT A, B, C, D FROM Perguntas WHERE pergunta = ?', (pergunta,))
        opcoes = cur.fetchone()
        return opcoes if opcoes else (None, None, None, None)
    
def obter_resposta(pergunta):
    with conectar() as conn:
        cur = conn.cursor()
        cur.execute('SELECT resposta FROM Perguntas WHERE pergunta = ?', (pergunta,))
        resposta = cur.fetchone()
        return resposta[0] if resposta else None
    
def obter_dificuldade(pergunta):
    with conectar() as conn:
        cur = conn.cursor()
        cur.execute('SELECT dificuldade FROM Perguntas WHERE pergunta = ?', (pergunta,))
        nivel_pergunta = cur.fetchone()
        return nivel_pergunta[0] if nivel_pergunta else None

def obter_categoria(pergunta):
    with conectar() as conn:
        cur = conn.cursor()
        cur.execute('SELECT categoria FROM Perguntas WHERE pergunta = ?', (pergunta,))
        categoria = cur.fetchone()
        return categoria[0] if categoria else None